
import { DbConnection } from './dist/stdb-client.mjs';
const conn = DbConnection.builder()
  .withUri('https://maincloud.spacetimedb.com')
  .withDatabaseName('smartcart-5dt35')
  .onConnect((c, identity, token) => {
    console.log('connected', identity.toHexString().slice(0, 12), 'token', token.length);
    console.log('reducer keys', Object.keys(c.reducers).slice(0, 20));
    c.subscriptionBuilder().onApplied(() => {
      console.log('stores', [...c.db.store.iter()].map(s => s.name + ':' + s.radiusM));
      console.log('orders', [...c.db.shopOrder.iter()].length, 'events', [...c.db.bagEvent.iter()].length);
      c.db.bagEvent.onInsert((ctx, row) => { console.log('LIVE bag_event', row.line, row.result); });
      const r = c.reducers.claimOperator({ code: 'QT85YBE4' });
      Promise.resolve(r).then(v => console.log('claim ok', v), e => console.log('claim err', String(e)));
      setTimeout(() => { process.exit(0); }, 6000);
    }).subscribe(['SELECT * FROM store', 'SELECT * FROM shop_order', 'SELECT * FROM bag_event']);
  })
  .onConnectError((ctx, e) => { console.log('connect error', String(e)); process.exit(1); })
  .build();
